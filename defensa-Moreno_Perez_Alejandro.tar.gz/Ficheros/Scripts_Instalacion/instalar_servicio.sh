#!/bin/bash

#Funcion para verificar e instalar un paquete
install_package() {
    package_name=$1
    if command -v $package_name &> /dev/null; then
         echo "$package_name ya esta instalado. Desinstalando..."
         sudo yum remove -y $package_name
    fi
    echo "Instalando $package_name ..."
    sudo yum install -y $package_name
    echo "$package_name instalado con éxito"
}

# Función para instalar el cliente
install_client() {
    echo "Instalando cliente..."
    install_package subversion.x86_64
    install_package davfs2

    
    #Instalar cadaver mediante codigo fuente
    mkdir /home/dit/client
    cd /home/dit/client/
    git clone https://github.com/notroj/cadaver
    cd cadaver
    yum install neon-devel.x86_64 
    ./autogen.sh
    ./configure
    make
    make install
    echo "Cliente instalado con éxito."
}

#Funcion para desinstalar el cliente
uninstall_client() {
    yum remove subversion.x86_64
    yum remove davfs2.x86_64
    echo "Subversion desinstalado..."
    echo "Davfs2 desinstalado..."
    
    rm -rf /usr/local/bin/cadaver
    rm -rf /usr/local/share/man/man1/cadaver.1
    echo "Cadaver desinstalado..."
}
# Función para instalar el servidor
install_server() {
    echo "Creando estructura de directorios donde se encontrara nginx al ser instalado por codigo fuente"
    mkdir /server
    mkdir /server/nginx/
    mkdir /server/extramodules/
    cd /server    
    echo "Instalando servidor..."
    install_package httpd
    install_package mod_ssl
    install_package mod_dav_svn #Necesario para Subversion
    # Instalar Nginx desde el código fuente
    echo "Compilando e instalando Nginx desde el código fuente..."
    curl -O nginx.org/download/nginx-1.22.1.tar.gz
    mv nginx-1.22.1.tar.gz /server/nginx
    cd /server/nginx
    tar xfvz /server/nginx/nginx-1.22.1.tar.gz 
    echo "Nginx ha sido extraido por completo"
    

    # Instalar módulo necesario para WebDAV
    echo "Instalando módulo nginx-dav-ext-method..."
    git clone https://github.com/arut/nginx-dav-ext-module.git
    
    #Comandos específicos para compilar e instalar el módulo y Nginx por codigo fuente
    mv nginx-dav-ext-module /server/extramodules/
    cd /server/nginx/nginx-1.22.1
    echo "Instalando prerequisitos del modulo"
    yum install libxslt-devel.x86_64 

    ./configure --with-http_dav_module --add-module=../../extramodules/nginx-dav-ext-module/
    make
    make install
    echo "Servidor instalado con éxito."
}

#Funcion para desinstalar servidor
uninstall_server() {
    echo "Desinstalando servidor..."
    yum remove httpd
    rm -rf /usr/local/nginx/
    rm -rf /var/log/nginx/
    rm -rf /etc/nginx/
    rm -rf /sbin/nginx
}

#Menú de instalación
echo "Seleccione una opción y asegurese de ejecutar el programa como root y en un directorio donde se volcaran algunos archivos:"
echo "1. Instalar cliente"
echo "2. Instalar servidor"
echo "3. Desinstalar cliente"
echo "4. Desinstalar servidor"
read -p "Ingrese el número de la opción: " option

case $option in
    1) install_client ;;
    2) install_server ;;
    3) uninstall_client ;;
    4) uninstall_server ;;
    *) echo "Opción no válida. Saliendo." ;;
esac
