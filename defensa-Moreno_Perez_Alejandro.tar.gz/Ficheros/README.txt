README.txt

Fichero de texto con pasos a seguir para usar el resto de ficheros incluidos
----------------------------------------------------------------------------

Instalacion

	1.- En la carpeta Scripts_Instalacion se encuentra un script de nombre
	instalar_servicio.sh . Comprobar permisos de ejecución y en caso de no
	tenerlos activarlos mediante "chmod +x instalar_servicio.sh". 

	2.- Ejecutar ./instalar_servicio.sh y seleccionar opción 1 o 2
	(Instalación del servidor o Instalacion del cliente)

Configuracion
	
	1.- Comprobar permisos de ejecución y en caso de no tenerlos activarlos
	mediante "chmod +x script_configuracion.sh"
	
	2.- Modificar ficheros incluidos en Ficheros_Configuracion y añadir
	IPs correspondientes, nombre de servidor y otros parametros de 
	posible interés.
	
	3.- Ejecutar script "./script_configuracion.sh" y rellenar los campos
	que se solicitan progresivamente


Desinstalacion

	1.- En la carpeta Scripts_Instalacion se encuentra un script de	nombre
        instalar_servicio.sh . Comprobar permisos de ejecución y en caso de no
        tenerlos activarlos mediante "chmod +x instalar_servicio.sh". 

	2.- Ejecutar ./instalar_servicio.sh y seleccionar opción 3 o 4
	(Desinstalacion del servidor o Desinstalacion del cliente)


------------------------------------------------------------------------------
