#!/bin/bash


#Ruta directorio configuracion
ruta_conf_apache="/etc/httpd/conf/"
ruta_conf_nginx="/usr/local/nginx/conf/"


cp "./Ficheros_Configuracion/httpd.conf" "$ruta_conf_apache"
echo "Moviendo fichero de configuracion de Apache..."
cp "./Ficheros_Configuracion/00-dav.conf" "/etc/httpd/conf.modules.d/00-dav.conf"
cp "./Ficheros_Configuracion/10-subversion.conf" "/etc/httpd/conf.modules.d/10-subversion.conf"
cp "./Ficheros_Configuracion/nginx.conf" "$ruta_conf_nginx"
echo "Moviendo fichero de configuración de Nginx..."



#Crear directorio de ficheros
echo "Creando red de directorios del servidor..."

rm -rf /var/www/html/webdav/
rm -rf /var/www/html/svn/

mkdir /var/www/html/webdav
mkdir /var/www/html/svn
mkdir /var/www/html/webdav/admin
mkdir /var/www/html/webdav/parte_trabajo
mkdir /var/www/html/webdav/dir1
mkdir /var/www/html/webdav/dir2

echo "Añadiendo permisos a ficheros..."
chown -R apache:apache /var/www/html/
chmod 755 /var/www/html/

echo "Añadiendo ficheros de prueba..."

echo "PASSWORD
user01:user01
admin:admin
user02:user02" > password.txt
mv password.txt /var/www/html/webdav/admin

echo "Parte de trabajo del dia de la defensa
Configurar cifrado SSL/TLS
Comprobar que funcionan los escenarios" > parte.txt
mv parte.txt /var/www/html/webdav/parte_trabajo

echo "Fichero de usuarios con menos permisos" > users.txt
mv users.txt /var/www/html/webdav/dir1

echo "Fichero de usuarios 2 con menos permisos" > users2.txt
mv user2.txt /var/www/html/webdav/dir2

#Crear .htpasswd en /etc/httpd/.htpasswd
echo "Creando usuario 1..."
htpasswd -c /etc/httpd/.htpasswd user01
echo "Creando usuario 2..."

htpasswd  /etc/httpd/.htpasswd user02
echo "Creando usuario admin..."

htpasswd  /etc/httpd/.htpasswd admin


#Crear .htpasswd en /var/www/html/webdav/.htpasswd
echo "Creando usuario 1..."

htpasswd -c /var/www/html/webdav/.htpasswd user01
echo "Creando usuario 2..."

htpasswd /var/www/html/webdav/.htpasswd user02
echo "Creando usuario admin..."
htpasswd /var/www/html/webdav/.htpasswd admin

#Configurar Subversion

svnadmin create /var/www/html/svn/webproject
mkdir /home/dit/SVN/
cd /home/dit/SVN/
echo "Hola Mundo este fichero sirve para comprobar el control de versiones" > versioning.txt
svn import -m "Initial checkin" . file:///var/www/html/svn/webproject
chown -R apache:apache /var/www/html/svn/webproject


#INSTALACION SSL MANUAL
#   cd /etc/pki/tls/certs/
#   openssl req -x509 -nodes -newkey rsa:2048 -keyout ../private/apache.key -out apache.crt

